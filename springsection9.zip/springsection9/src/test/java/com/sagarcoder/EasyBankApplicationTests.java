package com.sagarcoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
