package com.sagarcoder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sagarcoder.model.Loans;
import com.sagarcoder.repository.LoanRepository;

@RestController
public class LoansController {
	
	@Autowired
    private LoanRepository loanRepository;

	@GetMapping(path = "/myLoans")
	public List<Loans> getLoansDetails(@RequestParam int id) {
		List<Loans> loans = loanRepository.findByCustomerIdOrderByStartDtDesc(id);
		if (loans!=null) {
			return loans;
		} else {
			return null;
		}
	}
}
